package com.company.app;

public enum State {
    ACTIVE,
    SUSPENDED,
    CANCELLED
}

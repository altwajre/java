# Session API

https://gatling.io/docs/current/session/session_api/

package com.company.app.util

object Headers {
  val commonHeader = Map(
    "Content-Type" -> "application/json"
  )
}

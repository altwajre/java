# Scenario

https://gatling.io/docs/current/general/scenario/

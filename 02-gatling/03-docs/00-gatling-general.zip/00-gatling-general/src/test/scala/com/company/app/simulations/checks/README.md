# Checks

https://gatling.io/docs/current/http/http_check/

# Feeders

https://gatling.io/docs/current/session/feeder/

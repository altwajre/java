# Simulation

https://gatling.io/docs/current/general/simulation_setup/

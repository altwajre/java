
public abstract class CommonData<T> {
	abstract void doSomething();
}

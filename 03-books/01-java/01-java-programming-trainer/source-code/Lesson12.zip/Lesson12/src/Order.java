
public class Order extends CommonData{
	void doSomething(){
		System.out.println("Order. In doSomething()");
		
	}
}

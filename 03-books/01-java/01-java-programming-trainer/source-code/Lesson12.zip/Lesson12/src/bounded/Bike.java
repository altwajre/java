package bounded;

public class Bike extends Product {

}

package bounded;

public class Person {

}

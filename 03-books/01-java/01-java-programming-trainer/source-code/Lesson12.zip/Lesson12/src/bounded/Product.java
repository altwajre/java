package bounded;

public class Product {

}

package bounded;

public class Wheel extends Product {

}

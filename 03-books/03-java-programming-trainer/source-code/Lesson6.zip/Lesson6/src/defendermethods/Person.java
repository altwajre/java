package defendermethods;

public class Person {
 
// Comment out the method increasePay to see compiler's error
	public boolean increasePay(int percent){
	   System.out.println("In Person: increasePay()");
	   return true;
   }
   
}

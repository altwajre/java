package firstsamples;

public class Employee implements Payable{
	
	   public static void main(String[] args){
		   Employee emp = new Employee();
		   double limit = Payable.checkThePayIncreaseLimit();
	   }
     
}

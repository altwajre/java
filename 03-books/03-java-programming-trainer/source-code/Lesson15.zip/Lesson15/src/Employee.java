class Employee implements java.io.Serializable{
     String lName;
     String  fName;
     double salary;
     
     // private static final long serialVersionUID = 1234567890L;
}

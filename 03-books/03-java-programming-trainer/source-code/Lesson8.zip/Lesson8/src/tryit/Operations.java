
/**

 * Using eum to simplify the addition 
 * of a new operation if need be
 * 
 */
package tryit;

public enum Operations {
	ADDITION,
	SUBTRACTION,
	DIVISION,
	MULTIPLYING,
	ILLEGAL_OPERATION
}

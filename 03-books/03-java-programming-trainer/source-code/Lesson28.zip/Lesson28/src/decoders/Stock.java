package decoders;

public class Stock  {
	public String symbol;
	public double price;
}

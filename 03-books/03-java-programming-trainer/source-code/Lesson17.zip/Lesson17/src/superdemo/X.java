package superdemo;

public class X {
  void a(){
	   System.out.println("in X");
   }
}

package payincrease;

public class Person2 {

}

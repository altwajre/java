package payincrease;

public class Employee extends Person1{
  
  // some other code specific to Employee goes here
	
  public Employee(String name){
	  super(name);
  }
  
}
package payincrease;

public class Contractor extends Person1{
	  // some other code specific to Contractor goes here
	
	  public Contractor(String name){
		  super(name);
	  }
}
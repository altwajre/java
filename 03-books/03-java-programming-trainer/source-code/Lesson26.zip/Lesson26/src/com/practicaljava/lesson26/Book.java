package com.practicaljava.lesson26;

import java.io.Serializable;

public class Book implements Serializable {
	
	String title;
	double price;
}


public class TestCar1 {

	public static void main(String[] args) {
       Car car1 = new Car();
       Car car2 = new Car();
       
       car1.color = "red";
       car2.color ="blue";
       
       System.out.println("Car 1 is " + car1.color + ", and car 2 is " + car2.color);

	}

}

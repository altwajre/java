
public class Car {
	String color;
    int numberOfDoors;
    

    void startEngine() {
       // Some code goes here
    }
    void stopEngine() {
         int tempCounter=0;  
      // Some code goes here
    }

}

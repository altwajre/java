class JamesBondCar extends Car{
    int currentSubmergeDepth;
    boolean isGunOnBoard=true;
    final String MANUFACTURER = "J.B. Limited"; 
 
    void submerge() {
        currentSubmergeDepth = 50;
       // Some code goes here
    }
    void surface() {
      // Some code goes here
    }
}

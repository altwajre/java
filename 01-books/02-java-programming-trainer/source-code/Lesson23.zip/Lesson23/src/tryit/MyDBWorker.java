package tryit;

@DBParam(dbName = "Lesson23", uid = "JSmith", password = "Spring28")
public class MyDBWorker {

}

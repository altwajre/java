package reflection;
abstract public class Person {
  abstract public void raiseSalary();
}

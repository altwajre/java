package com.company.app;

import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class Offer {
  private String name;
  private List<Map<String, Object>> products;
}

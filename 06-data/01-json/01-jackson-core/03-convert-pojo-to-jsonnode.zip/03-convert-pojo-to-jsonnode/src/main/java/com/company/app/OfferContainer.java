package com.company.app;

import lombok.Data;

@Data
public class OfferContainer {
  private String key;
  private Offer offer;
}

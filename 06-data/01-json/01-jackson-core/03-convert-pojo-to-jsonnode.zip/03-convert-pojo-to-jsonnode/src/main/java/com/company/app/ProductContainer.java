package com.company.app;

import lombok.Data;

@Data
public class ProductContainer {
  private String key;
  private Product product;
}

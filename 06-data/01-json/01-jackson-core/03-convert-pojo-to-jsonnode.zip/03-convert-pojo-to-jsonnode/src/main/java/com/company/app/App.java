package com.company.app;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class App {
  public static void main(String[] args) throws JsonProcessingException {
    ObjectMapper mapper = new ObjectMapper();

    Person person = new Person();
    person.setName("Will");
    person.setAge(28);
    person.setFriends(new String[]{"Tom", "Dick", "Harry"});

    person.setBooks(Arrays.asList("Java", "Python"));

    Map<String, String> keys = new HashMap<>();
    keys.put("1", "Apple");
    keys.put("2", "Orange");
    person.setKeys(keys);

    Map<String, Object> productMap = new HashMap<>();
    productMap.put("key", "abc");
    Product product = new Product();
    product.setName("product_1");
    productMap.put("product", product);

    Map<String, Object> offerMap = new HashMap<>();
    offerMap.put("key", "123");
    Offer offer = new Offer();
    offer.setName("offer_1");
    offerMap.put("offer", offer);
    offer.setProducts(Arrays.asList(productMap));

    person.setOffers(Arrays.asList(offerMap));

    System.out.println("# Pojo to JsonNode");
    JsonNode customerJson = mapper.convertValue(person, JsonNode.class);
    System.out.println(customerJson);

    System.out.println("# JsonNode to Pojo");
    Person jsonToPojo = mapper.treeToValue(customerJson, Person.class);
    System.out.println(jsonToPojo);


  }
}
/*
output:
# Pojo to JsonNode
{
  "id": null,
  "name": "Will",
  "age": 28,
  "friends": [
    "Tom",
    "Dick",
    "Harry"
  ],
  "books": [
    "Java",
    "Python"
  ],
  "keys": {
    "1": "Apple",
    "2": "Orange"
  },
  "offers": [
    {
      "offer": {
        "name": "offer_1",
        "products": [
          {
            "product": {
              "name": "product_1"
            },
            "key": "abc"
          }
        ]
      },
      "key": "123"
    }
  ]
}
# JsonNode to Pojo
Person(id=null, name=Will, age=28, friends=[Tom, Dick, Harry], books=[Java, Python], keys={1=Apple, 2=Orange}, offers=[{offer={name=offer_1, products=[{product={name=product_1}, key=abc}]}, key=123}])
 */

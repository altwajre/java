package com.company.app;

import lombok.Data;

@Data
public class Product {
  private String name;
}
